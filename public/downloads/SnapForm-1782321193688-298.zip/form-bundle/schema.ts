import { z } from 'zod';

export const TestFormSchema = z.object({
  email: z.string().email('Invalid email address').min(1, 'Email is required'),
});

export type TestFormInput = z.infer<typeof TestFormSchema>;
