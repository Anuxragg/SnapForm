import { NextRequest, NextResponse } from 'next/server';
import { TestFormSchema } from './schema';

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();

    // Server-side validation using Zod
    const validationResult = TestFormSchema.safeParse(data);

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          message: 'Validation failed',
          errors: validationResult.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const validatedData = validationResult.data;

    // TODO: Perform database operations, emails, integrations, or Stripe payments here.
    console.log('Successfully received validated form submission:', validatedData);

    return NextResponse.json({
      success: true,
      message: 'Form submitted and processed successfully on the server!',
      receivedData: validatedData,
    });
  } catch (error: any) {
    console.error('Error handling form submission API route:', error);
    return NextResponse.json(
      {
        success: false,
        message: 'Internal server error occurred',
        error: error.message,
      },
      { status: 500 }
    );
  }
}
