'use client';

import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';

// shadcn UI Imports
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';

import { ContactInquiryFormSchema, type ContactInquiryFormInput } from './schema';

export default function ContactInquiryForm() {
  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactInquiryFormInput>({
    resolver: zodResolver(ContactInquiryFormSchema),
    defaultValues: {} as any
  });

  const onSubmit = async (data: ContactInquiryFormInput) => {
    try {
      // In production, file elements require FormData. We handle files dynamically here:
      let payload: any = data;
      
      // Check if file fields exist and package into FormData if necessary
      const hasFiles = Object.keys(data).some(key => data[key as keyof ContactInquiryFormInput] instanceof FileList);
      
      if (hasFiles) {
        const formData = new FormData();
        Object.entries(data).forEach(([key, value]) => {
          if (value instanceof FileList) {
            if (value[0]) formData.append(key, value[0]);
          } else if (Array.isArray(value)) {
            formData.append(key, JSON.stringify(value));
          } else {
            formData.append(key, String(value));
          }
        });
        payload = formData;
      }

      const response = await fetch('/api/submit', {
        method: 'POST',
        headers: hasFiles ? undefined : {
          'Content-Type': 'application/json',
        },
        body: hasFiles ? payload : JSON.stringify(payload),
      });

      const result = await response.json();

      if (response.ok && result.success) {
        toast.success(result.message || 'Form submitted successfully!');
        reset();
      } else {
        throw new Error(result.message || 'Submission failed.');
      }
    } catch (error: any) {
      toast.error(error.message || 'Something went wrong. Please try again.');
    }
  };

  return (
    <Card className="border border-neutral-200/60 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl shadow-neutral-100/50 p-8 max-w-lg mx-auto">
      <CardHeader className="space-y-1.5">
        <CardTitle className="text-2xl font-bold tracking-tight text-neutral-900">
          Contact Inquiry Form
        </CardTitle>
        <CardDescription className="text-neutral-500">
          Please fill out the form details below.
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <CardContent className="space-y-5">

        <div className="space-y-2">
          <Label htmlFor="fullName" className="text-sm font-semibold text-neutral-700">
            Full Name <span className="text-red-500">*</span>
          </Label>
          <Input
            id="fullName"
            type="text"
            placeholder="John Doe"
            className="rounded-xl border-neutral-200 focus:ring-2"
            {...register('fullName')}
          />
          {errors.fullName && (
            <p className="text-xs font-medium text-red-500">{errors.fullName?.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-sm font-semibold text-neutral-700">
            Email Address <span className="text-red-500">*</span>
          </Label>
          <Input
            id="email"
            type="email"
            placeholder="john.doe@example.com"
            className="rounded-xl border-neutral-200 focus:ring-2"
            {...register('email')}
          />
          {errors.email && (
            <p className="text-xs font-medium text-red-500">{errors.email?.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="subject" className="text-sm font-semibold text-neutral-700">
            Subject <span className="text-red-500">*</span>
          </Label>
          <Input
            id="subject"
            type="text"
            placeholder="How can we help you?"
            className="rounded-xl border-neutral-200 focus:ring-2"
            {...register('subject')}
          />
          {errors.subject && (
            <p className="text-xs font-medium text-red-500">{errors.subject?.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="message" className="text-sm font-semibold text-neutral-700">
            Message <span className="text-red-500">*</span>
          </Label>
          <Textarea
            id="message"
            placeholder="Describe your inquiry in detail..."
            className="min-h-[100px] rounded-xl border-neutral-200 focus:ring-2"
            {...register('message')}
          />
          {errors.message && (
            <p className="text-xs font-medium text-red-500">{errors.message?.message}</p>
          )}
        </div>
        </CardContent>
        
        <CardFooter className="pt-4">
          <Button
            type="submit"
            disabled={isSubmitting}
            style={{ backgroundColor: '#ff4f19' }}
            className="w-full text-white font-medium transition-all duration-200 rounded-xl shadow-lg shadow-primary-500/20 hover:scale-[1.01] active:scale-[0.99]"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Form'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
