import { z } from 'zod';

export const ContactInquiryFormSchema = z.object({
  fullName: z.string().min(2, 'Full Name must be at least 2 characters').max(50, 'Maximum length is 50'),
  email: z.string().email('Invalid email address').min(1, 'Email is required'),
  subject: z.string().min(5, 'Subject must be at least 5 characters'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

export type ContactInquiryFormInput = z.infer<typeof ContactInquiryFormSchema>;
